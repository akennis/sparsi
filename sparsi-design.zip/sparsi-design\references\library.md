# Available Library Ops

## Math — float
AddFloatOp: deterministic float64 addition. Inputs: A *float64, B *float64. Output: Result float64.
SubFloatOp: A minus B (float64). Inputs: A *float64, B *float64. Output: Result float64.
MulFloatOp: A multiplied by B (float64). Inputs: A *float64, B *float64. Output: Result float64.
DivFloatOp: A divided by B (float64). Inputs: A *float64, B *float64. Output: Result float64. Error if B==0.
PowFloatOp: A raised to the power B (float64). Inputs: A *float64, B *float64. Output: Result float64.
ModFloatOp: floating-point remainder of A/B. Inputs: A *float64, B *float64. Output: Result float64. Error if B==0.
RoundOp: rounds Value to nearest integer. Input: Value *float64. Output: Result float64.
ClampFloatOp: clamps Value to [Min, Max] (float64). Inputs: Value *float64, Min *float64, Max *float64. Output: Result float64.
SumFloatOp: sums all values in a float64 slice. Input: Values *[]float64. Output: Result float64.
MinFloatOp: returns the minimum value in a float64 slice. Input: Values *[]float64. Output: Result float64. Error if empty.
MaxFloatOp: returns the maximum value in a float64 slice. Input: Values *[]float64. Output: Result float64. Error if empty.
PackMathOperandsOp: packs two float64 inputs into a MathOperands struct. Inputs: A *float64, B *float64. Output: Result MathOperands.


## Math — int
AddIntOp: deterministic int addition. Inputs: A *int, B *int. Output: Result int.
SubIntOp: A minus B (int). Inputs: A *int, B *int. Output: Result int.
MulIntOp: A multiplied by B (int). Inputs: A *int, B *int. Output: Result int.
DivIntOp: A divided by B (int, truncates toward zero). Inputs: A *int, B *int. Output: Result int. Error if B==0.
PowIntOp: A raised to the power B (int). Inputs: A *int, B *int. Output: Result int. Error if B<0.
ModIntOp: integer remainder of A/B. Inputs: A *int, B *int. Output: Result int. Error if B==0.
SumIntOp: sums all values in an int slice. Input: Values *[]int. Output: Result int.
ClampIntOp: clamps Value to [Min, Max] (int). Inputs: Value *int, Min *int, Max *int. Output: Result int.
MinIntOp: returns the minimum value in an int slice. Input: Values *[]int. Output: Result int. Error if empty.
MaxIntOp: returns the maximum value in an int slice. Input: Values *[]int. Output: Result int. Error if empty.


## Math — cast
IntToFloat64Op: widens an int wire to float64. Input: Value *int. Output: Result float64.
Float64ToIntOp: truncates a float64 wire to int. Input: Value *float64. Output: Result int.


## String — cast
Float64ToStringOp: formats a float64 as string using %v. Input: Value *float64. Output: Result string.
IntToStringOp: formats an int as string using %v. Input: Value *int. Output: Result string.
BoolToStringOp: formats a bool as string ("true" or "false"). Input: Value *bool. Output: Result string.
ToStringOp: formats any upstream pointer value as string using %v; accepts any pointer type via reflection (escape hatch for custom struct wires). Input: Value (any pointer). Output: Result string.


## String
StringLookupOp: looks up Key in a hardcoded string→string map; returns "" on miss.
  Params: map — JSON-encoded key→value pairs (e.g. {"hamburger":"ketchup","hotdog":"mustard"}).
  Input:  Key *string.
  Output: Result string (empty string if key not found).
StringToLowerOp: converts a string to lowercase. Input: Value *string. Output: Result string.
StringConcatOp: concatenates two strings. Inputs: A *string, B *string. Output: Result string.
StringSplitOp: splits a string by a separator. Param: sep (default ","). Input: Input *string. Output: Result []string.
RegexMatchOp: reports whether the input matches a compiled regex. Param: pattern (required). Input: Input *string. Output: Match bool.
RegexExtractOp: returns the first match (or submatch group 1 if present) of a regex. Param: pattern (required). Input: Input *string. Output: Result string (empty if no match).


## Bool
BoolNotOp: logical NOT. Input: Value *bool. Output: Result bool.
BoolAndOp: logical AND. Inputs: A *bool, B *bool. Output: Result bool.
BoolOrOp: logical OR. Inputs: A *bool, B *bool. Output: Result bool.


## Predicate — float
IfFloatGtOp: reports whether A > B. Inputs: A *float64, B *float64. Output: Match bool.
IfFloatLtOp: reports whether A < B. Inputs: A *float64, B *float64. Output: Match bool.
IfFloatEqOp: reports whether A == B. Inputs: A *float64, B *float64. Output: Match bool.
IfFloatGeOp: reports whether A >= B. Inputs: A *float64, B *float64. Output: Match bool.
IfFloatLeOp: reports whether A <= B. Inputs: A *float64, B *float64. Output: Match bool.


## Predicate — int
IfIntGtOp: reports whether A > B. Inputs: A *int, B *int. Output: Match bool.
IfIntLtOp: reports whether A < B. Inputs: A *int, B *int. Output: Match bool.
IfIntEqOp: reports whether A == B. Inputs: A *int, B *int. Output: Match bool.
IfIntGeOp: reports whether A >= B. Inputs: A *int, B *int. Output: Match bool.
IfIntLeOp: reports whether A <= B. Inputs: A *int, B *int. Output: Match bool.


## Predicate — string
IfStringContainsOp: reports whether A contains B as a substring. Inputs: A *string, B *string. Output: Match bool.
IfStringHasPrefixOp: reports whether A starts with B. Inputs: A *string, B *string. Output: Match bool.
IfStringHasSuffixOp: reports whether A ends with B. Inputs: A *string, B *string. Output: Match bool.
IfStringRegexMatchOp: reports whether the input matches a compiled regex. Param: pattern (required). Input: Input *string. Output: Match bool.
IfStringEqOp: reports whether two strings are equal. Inputs: A *string, B *string. Output: Match bool.


## Predicate — empty / range
IfEmptyStringOp: reports whether Value is nil or the empty string. Input: Value *string. Output: Match bool.
IfEmptySliceStringOp: reports whether Value is nil or has length 0. Input: Value *[]string. Output: Match bool.
IfEmptySliceFloat64Op: reports whether Value is nil or has length 0. Input: Value *[]float64. Output: Match bool.
BetweenFloatOp: reports whether Min <= Value <= Max (inclusive on both ends). Inputs: Value *float64, Min *float64, Max *float64. Output: Match bool.


## Select / Switch / Default
SelectStringOp: ternary; returns IfTrue when Cond is true, otherwise IfFalse. Inputs: Cond *bool, IfTrue *string, IfFalse *string. Output: Result string.
SelectFloat64Op: ternary; returns IfTrue when Cond is true, otherwise IfFalse. Inputs: Cond *bool, IfTrue *float64, IfFalse *float64. Output: Result float64.
SelectIntOp: ternary; returns IfTrue when Cond is true, otherwise IfFalse. Inputs: Cond *bool, IfTrue *int, IfFalse *int. Output: Result int.
SelectBoolOp: ternary; returns IfTrue when Cond is true, otherwise IfFalse. Inputs: Cond *bool, IfTrue *bool, IfFalse *bool. Output: Result bool.
SwitchStringOp: looks up Key in a params-configured cases map; returns the configured default on miss.
  Params: cases — JSON-encoded key→value pairs (e.g. {"red":"stop","green":"go"}).
          default — string returned when Key is nil or not in cases (default "").
  Input:  Key *string.
  Output: Result string.
DefaultStringOp: returns Default when Value is nil or the empty string; otherwise returns Value. Inputs: Value *string, Default *string. Output: Result string.
DefaultFloat64Op: returns Default when Value is nil; zero is treated as a valid value. Inputs: Value *float64, Default *float64. Output: Result float64.
DefaultIntOp: returns Default when Value is nil; zero is treated as a valid value. Inputs: Value *int, Default *int. Output: Result int.


## Slice
SliceLenOp: returns the length of a string slice. Input: Input *[]string. Output: Result int.
SliceAtOp: returns the element at a given index. Param: index (int, used when Index wire is absent). Inputs: Input *[]string, Index *int (optional wire). Output: Result string.
SliceFirstOp: returns the first element. Input: Input *[]string. Output: Result string. Error if empty.
SliceLastOp: returns the last element. Input: Input *[]string. Output: Result string. Error if empty.
SliceContainsOp: reports whether a slice contains a value. Inputs: Input *[]string, Value *string. Output: Match bool.
SliceJoinOp: joins a string slice with a separator. Param: sep (default ","). Input: Input *[]string. Output: Result string.
SliceFilterEqOp: returns elements equal to Value. Inputs: Input *[]string, Value *string. Output: Result []string.
SliceTopKOp: returns indices of the K highest scores in descending order. Param: k (int). Input: Scores *[]float64. Output: Result []int.


## Retrieval
RetrieveOp: pulls the top-k documents most relevant to a query from a registered Retriever (RAG fan-in).
  Params:   k string — number of documents to return (default "5"). Lower values keep prompts compact; higher values broaden recall.
            retriever_id string — selects a Retriever registered via library.RegisterRetriever (default "" → process default set via library.SetDefaultRetriever).
            credential_ref string — opaque credential identifier installed into ctx for the Retriever (default ""; consumed by library.ResolveEmbeddingClient inside vector-store-backed Retrievers; ignored by Retrievers that don't embed). credential_ref is a LOOKUP REFERENCE (e.g. an env-var name like "CLAUDE_API_KEY" or a factory key like "voyage-prod") that a registered EmbeddingClientFactory translates into a real credential — it is NOT the secret value itself. Never put an API key, OAuth token, vault URL, or any other secret material as the credential_ref value in vertex params: those values land verbatim in the generated main.go, get committed to git, and end up indexed by every tool that reads the repo.
            client_factory_id string — selects a registered EmbeddingClientFactory by id for the Retriever's embedding lookup (default "" → process default set via library.SetDefaultEmbeddingClientFactory). NOTE: the bundled EnvEmbeddingClientFactory only supports provider="gemini". For any other embedding provider (Claude, OpenAI, Voyage, Cohere, …) you MUST register a custom factory via library.RegisterEmbeddingClientFactory (or library.SetDefaultEmbeddingClientFactory) before engine.Run — the default rejects unknown providers with an error. This is asymmetric with AI ops, whose bundled EnvAIClientFactory supports both Claude and Gemini.
            api_factory_timeout_ms string — deadline for the EmbeddingClientFactory credential lookup in milliseconds (default "30000"; "0" disables). Bounds the factory's credential-lookup leg only (Vault / Secrets Manager / KMS round trip); the subsequent Retriever.Retrieve call is NOT covered by this budget. Mirrors AIClientFactory's api_factory_timeout_ms.
            embed_timeout_ms string — wallclock deadline applied to the ENTIRE Retriever.Retrieve call in milliseconds (embedding API call + vector search + post-filtering — whatever the Retriever does end-to-end). Default "" / "0" = no per-op deadline (the call honors only the ambient ctx). Wraps the Retrieve invocation with context.WithTimeout; when it fires, the op returns the wrapped error and the underlying ctx.DeadlineExceeded. Complementary to api_factory_timeout_ms: factory_timeout caps the credential lookup, embed_timeout caps the actual retrieval work.
  Inputs:   Query *string — the natural-language search query.
  Outputs:  Documents []library.Document — full records ({ID, Content, Score, Metadata}) sorted best-first. Use when downstream ops need IDs, scores, or Retriever-specific metadata (citation URL, highlights, timestamps, ACL flags, per-field scores — anything the Retriever stuffed into Metadata).
            Texts []string — parallel slice of Documents[i].Content in the same order. Wire this into AI ops that take *[]string (AISummarizeOp, AIRerankOp, AIBestMatchOp candidates).
  Setup is fail-fast: if no Retriever is registered the graph errors before any vertex runs. Call SetDefaultRetriever (or RegisterRetriever) before engine.Run. The three credential params are installed into ctx via library.WithEmbeddingCredentials and consumed by user Retrievers via library.ResolveEmbeddingClient — omit them for Retrievers that don't embed (BM25, hosted search with its own auth, etc.).
RetrieveWithFiltersOp: like RetrieveOp but with filters that scope the retrieval. Filters may come from a runtime Filters input wire (values produced by upstream graph ops — tenant id from an auth step, category from a classifier, date range from a planner), from a compile-time static_filters param (values known when the graph is wired — a hardcoded tenant id, a fixed locale), or both.
  Params:   k string — number of documents to return (default "5").
            retriever_id string — selects a Retriever registered via library.RegisterRetriever (default "" → process default).
            credential_ref string — opaque credential identifier installed into ctx for the Retriever (default ""; consumed by library.ResolveEmbeddingClient inside vector-store-backed Retrievers; ignored by Retrievers that don't embed). credential_ref is a LOOKUP REFERENCE (e.g. an env-var name like "CLAUDE_API_KEY" or a factory key like "voyage-prod") that a registered EmbeddingClientFactory translates into a real credential — it is NOT the secret value itself. Never put an API key, OAuth token, vault URL, or any other secret material as the credential_ref value in vertex params: those values land verbatim in the generated main.go, get committed to git, and end up indexed by every tool that reads the repo.
            client_factory_id string — selects a registered EmbeddingClientFactory by id for the Retriever's embedding lookup (default "" → process default set via library.SetDefaultEmbeddingClientFactory). NOTE: the bundled EnvEmbeddingClientFactory only supports provider="gemini". For any other embedding provider (Claude, OpenAI, Voyage, Cohere, …) you MUST register a custom factory via library.RegisterEmbeddingClientFactory (or library.SetDefaultEmbeddingClientFactory) before engine.Run — the default rejects unknown providers with an error. This is asymmetric with AI ops, whose bundled EnvAIClientFactory supports both Claude and Gemini.
            api_factory_timeout_ms string — deadline for the EmbeddingClientFactory credential lookup in milliseconds (default "30000"; "0" disables). Bounds the factory's credential-lookup leg only (Vault / Secrets Manager / KMS round trip); the subsequent Retriever.Retrieve call is NOT covered by this budget.
            embed_timeout_ms string — wallclock deadline applied to the ENTIRE Retriever.Retrieve call in milliseconds (embedding API call + vector search + post-filtering — whatever the Retriever does end-to-end). Default "" / "0" = no per-op deadline (the call honors only the ambient ctx). Wraps the Retrieve invocation with context.WithTimeout; when it fires, the op returns the wrapped error and the underlying ctx.DeadlineExceeded. Complementary to api_factory_timeout_ms.
            static_filters string — comma-separated key=value pairs of filters known at graph-build time (e.g. "tenant=acme,locale=en"). Parsed at Setup and merged into the filter map every Run. Default "" = no static filters. Malformed entries (no "=", empty key, duplicate key) fail at Setup. Use this when filter values are fixed for the lifetime of the program; use the Filters wire for values computed upstream; supply both to combine them. When both static_filters is unset AND the Filters wire is empty/disconnected at Run, the op logs a WARN and retrieves without filters.
  Inputs:   Query *string — the natural-language search query.
            Filters *map[string]string — optional request-scoped filters. May be left disconnected when static_filters is set. When connected, the map is merged on top of static_filters every Run (runtime wins on key collision). Empty or nil runtime map is treated as "no runtime filters" and falls through to static_filters. The merged map is installed into ctx via library.WithRetrievalFilters; the Retriever reads it via library.RetrievalFiltersFromContext. Values are strings by convention — Retriever implementations parse numbers, split CSV lists, etc.
  Outputs:  Documents []library.Document — full records ({ID, Content, Score, Metadata}) sorted best-first.
            Texts []string — parallel slice of Documents[i].Content.
  Use this op when at least one filter value is needed; use plain RetrieveOp when no filters are needed. Retriever implementations that don't understand the filter keys must ignore them, not error. Embedding credentials install into ctx alongside the filters; both values coexist.
ValidateCitationsOp: filters LLM-emitted citations against an allow-list of source identifiers — a security control. Hallucinated source names (anything the model invents or imports from its training corpus) are dropped; only entries that exactly match a member of the allow-list survive into Accepted. Use this op to enforce citation integrity at the boundary between an untrusted AI op and a downstream surface (UI, audit log, database write).
  Inputs:   Raw *[]string — the citations parsed out of the model's response (typically the Sources slice produced by your example's ParseCitations step over the AI op's raw output). Order is preserved into Accepted / Rejected.
            Allowed *[]string — the allow-list of source identifiers the model was permitted to cite. The canonical pattern is: pipe the retrieved []library.Document slice (from RetrieveOp or RetrieveWithFiltersOp) into a sources-extraction step that emits []string of identifiers (e.g. each Document's Metadata[library.MetadataSource]), then wire that []string here. Build the allow-list from the documents the model actually saw, NOT from the full loaded corpus — a model that hallucinates the filename of a real-but-unretrieved document would otherwise slip past the check.
  Outputs:  Accepted []string — citations from Raw that appear in Allowed. De-duplicated (a model that repeats the same source twice yields one Accepted entry) and ordered by first appearance in Raw.
            Rejected []string — citations from Raw that do NOT appear in Allowed. De-duplicated and ordered by first appearance in Raw. Surface these via slog at Warn (not Error) for observability — they are signal about model behavior, not graph failure.
  Membership is an exact string match against the Allowed set; no normalization, no case-folding, no whitespace trimming (upstream parsing is expected to trim already). Nil/empty Raw -> both outputs empty. Nil/empty Allowed with non-empty Raw -> every citation rejected. Run never returns an error; this is a pure deterministic op (no I/O, no parsing).
  WARNING: this op is the right place to enforce citation integrity. Do NOT route unfiltered citations (the Raw input, or ParseCitations output upstream of this op) to user-facing surfaces, audit logs, or downstream tooling where they will be treated as trustworthy — ALWAYS route the Accepted output instead, and slog-warn the Rejected output.


## AI
ModeSelectOp: AI-powered classifier — maps arbitrary input text to exactly one of a fixed set of categories.
  Params:   categories string — comma-separated list of valid output values (e.g. "arithmetic expression,city name").
            max_retries string — parse/validation retries (default "3").
            api_retries string — transient-error retries with exponential backoff (default "3").
            api_retry_delay_ms string — initial backoff delay in milliseconds (default "500").
            api_factory_timeout_ms string — deadline for AIClientFactory credential lookup in milliseconds (default "30000"; "0" disables).
            provider string — AI provider: "claude" (default) or "gemini".
            model string — model name passed through to the provider (default: "claude-sonnet-4-6").
            credential_ref string — opaque credential identifier passed to AIClientFactory (default ""; ignored by the bundled env-var factory).
            client_factory_id string — selects a registered AIClientFactory by id (default "" → process default).
  Inputs:   Input *string — the text to classify.
  Outputs:  Result string — exactly one of the specified categories.
AIComputeStringToStringOp: AI-powered string→string computation.
  Params:   operation string — plain-English description (e.g. "suggest a condiment that pairs with the given food").
            max_retries string — parse retries (default "3").
            api_retries string — transient-error retries with exponential backoff (default "3").
            api_retry_delay_ms string — initial backoff delay in milliseconds (default "500").
            api_factory_timeout_ms string — deadline for AIClientFactory credential lookup in milliseconds (default "30000"; "0" disables).
            provider string — AI provider: "claude" (default) or "gemini".
            model string — model name passed through to the provider (default: "claude-sonnet-4-6").
            credential_ref string — opaque credential identifier passed to AIClientFactory (default ""; ignored by the bundled env-var factory).
            client_factory_id string — selects a registered AIClientFactory by id (default "" → process default).
  Inputs:   Input *string — the query string.
  Outputs:  Result string, Reasoning string.
AIComputeMathOperandsToFloat64Op: AI-powered fallback for operations not available in the library.
  Params:   operation string — plain-English description of what to compute (e.g. "multiply A by B").
            max_retries string — number of parse retries (default "3").
            api_retries string — transient-error retries with exponential backoff (default "3").
            api_retry_delay_ms string — initial backoff delay in milliseconds (default "500").
            api_factory_timeout_ms string — deadline for AIClientFactory credential lookup in milliseconds (default "30000"; "0" disables).
            provider string — AI provider: "claude" (default) or "gemini".
            model string — model name passed through to the provider (default: "claude-sonnet-4-6").
            credential_ref string — opaque credential identifier passed to AIClientFactory (default ""; ignored by the bundled env-var factory).
            client_factory_id string — selects a registered AIClientFactory by id (default "" → process default).
  Inputs:   Input *MathOperands (connect PackMathOperandsOp's Result wire).
  Outputs:  Result float64, Reasoning string.
AIExtractStringSliceOp: AI-powered extraction of a list from text.
  Params:   operation string — plain-English description (e.g. "extract all ingredient names from this recipe").
            max_retries string — parse retries (default "3").
            api_retries string — transient-error retries with exponential backoff (default "3").
            api_retry_delay_ms string — initial backoff delay in milliseconds (default "500").
            api_factory_timeout_ms string — deadline for AIClientFactory credential lookup in milliseconds (default "30000"; "0" disables).
            provider string — AI provider: "claude" (default) or "gemini".
            model string — model name passed through to the provider (default: "claude-sonnet-4-6").
            credential_ref string — opaque credential identifier passed to AIClientFactory (default ""; ignored by the bundled env-var factory).
            client_factory_id string — selects a registered AIClientFactory by id (default "" → process default).
  Inputs:   Input *string.
  Outputs:  Result []string (CSV), Reasoning string.
AIExtractMapOp: AI-powered extraction of key-value pairs from text.
  Params:   operation string — plain-English description (e.g. "extract name, email, and city from this contact info").
            max_retries string — parse retries (default "3").
            api_retries string — transient-error retries with exponential backoff (default "3").
            api_retry_delay_ms string — initial backoff delay in milliseconds (default "500").
            api_factory_timeout_ms string — deadline for AIClientFactory credential lookup in milliseconds (default "30000"; "0" disables).
            provider string — AI provider: "claude" (default) or "gemini".
            model string — model name passed through to the provider (default: "claude-sonnet-4-6").
            credential_ref string — opaque credential identifier passed to AIClientFactory (default ""; ignored by the bundled env-var factory).
            client_factory_id string — selects a registered AIClientFactory by id (default "" → process default).
  Inputs:   Input *string.
  Outputs:  Result map[string]string (key=value CSV), Reasoning string.
AIParseNumberOp: AI-powered number extraction — converts text to float64.
  Params:   operation string — plain-English description (default: leave empty to extract the number from the text).
            max_retries string — parse retries (default "3").
            api_retries string — transient-error retries with exponential backoff (default "3").
            api_retry_delay_ms string — initial backoff delay in milliseconds (default "500").
            api_factory_timeout_ms string — deadline for AIClientFactory credential lookup in milliseconds (default "30000"; "0" disables).
            provider string — AI provider: "claude" (default) or "gemini".
            model string — model name passed through to the provider (default: "claude-sonnet-4-6").
            credential_ref string — opaque credential identifier passed to AIClientFactory (default ""; ignored by the bundled env-var factory).
            client_factory_id string — selects a registered AIClientFactory by id (default "" → process default).
  Inputs:   Input *string (e.g. "two thousand", "$1.2k", "the price is 42").
  Outputs:  Result float64, Reasoning string.
AISummarizeOp: AI-powered summarization of a list of strings into one result string.
  Params:   operation string — plain-English instruction (e.g. "summarize into one concise sentence").
            max_retries string — parse retries (default "3").
            api_retries string — transient-error retries with exponential backoff (default "3").
            api_retry_delay_ms string — initial backoff delay in milliseconds (default "500").
            api_factory_timeout_ms string — deadline for AIClientFactory credential lookup in milliseconds (default "30000"; "0" disables).
            provider string — AI provider: "claude" (default) or "gemini".
            model string — model name passed through to the provider (default: "claude-sonnet-4-6").
            credential_ref string — opaque credential identifier passed to AIClientFactory (default ""; ignored by the bundled env-var factory).
            client_factory_id string — selects a registered AIClientFactory by id (default "" → process default).
  Inputs:   Input *[]string — items to summarize.
  Outputs:  Result string, Reasoning string.
AIClassifyMultiLabelOp: AI-powered multi-label classifier — maps input to zero or more categories.
  Params:   categories string — comma-separated list of valid labels (e.g. "billing,bug,feature,spam").
            max_retries string — parse/validation retries (default "3").
            api_retries string — transient-error retries with exponential backoff (default "3").
            api_retry_delay_ms string — initial backoff delay in milliseconds (default "500").
            api_factory_timeout_ms string — deadline for AIClientFactory credential lookup in milliseconds (default "30000"; "0" disables).
            provider string — AI provider: "claude" (default) or "gemini".
            model string — model name passed through to the provider (default: "claude-sonnet-4-6").
            credential_ref string — opaque credential identifier passed to AIClientFactory (default ""; ignored by the bundled env-var factory).
            client_factory_id string — selects a registered AIClientFactory by id (default "" → process default).
  Inputs:   Input *string.
  Outputs:  Result []string — subset of categories (CSV), Reasoning string.
AIScoreOp: AI-powered scoring — returns a float64 in [0,1] measuring a criterion.
  Params:   criterion string — what to measure (e.g. "relevance to the query", "toxicity").
            max_retries string — parse/validation retries (default "3").
            api_retries string — transient-error retries with exponential backoff (default "3").
            api_retry_delay_ms string — initial backoff delay in milliseconds (default "500").
            api_factory_timeout_ms string — deadline for AIClientFactory credential lookup in milliseconds (default "30000"; "0" disables).
            provider string — AI provider: "claude" (default) or "gemini".
            model string — model name passed through to the provider (default: "claude-sonnet-4-6").
            credential_ref string — opaque credential identifier passed to AIClientFactory (default ""; ignored by the bundled env-var factory).
            client_factory_id string — selects a registered AIClientFactory by id (default "" → process default).
  Inputs:   Input *string.
  Outputs:  Result float64 ∈ [0,1], Reasoning string.
AIBoolOp: AI-powered yes/no predicate.
  Params:   predicate string — the question to answer about the input (e.g. "does this text contain PII?").
            max_retries string — parse/validation retries (default "3").
            api_retries string — transient-error retries with exponential backoff (default "3").
            api_retry_delay_ms string — initial backoff delay in milliseconds (default "500").
            api_factory_timeout_ms string — deadline for AIClientFactory credential lookup in milliseconds (default "30000"; "0" disables).
            provider string — AI provider: "claude" (default) or "gemini".
            model string — model name passed through to the provider (default: "claude-sonnet-4-6").
            credential_ref string — opaque credential identifier passed to AIClientFactory (default ""; ignored by the bundled env-var factory).
            client_factory_id string — selects a registered AIClientFactory by id (default "" → process default).
  Inputs:   Input *string.
  Outputs:  Result bool, Reasoning string.
AIBestMatchOp: AI-powered semantic selection — returns the index of the best-matching candidate.
  Params:   max_retries string — parse/validation retries (default "3").
            api_retries string — transient-error retries with exponential backoff (default "3").
            api_retry_delay_ms string — initial backoff delay in milliseconds (default "500").
            api_factory_timeout_ms string — deadline for AIClientFactory credential lookup in milliseconds (default "30000"; "0" disables).
            provider string — AI provider: "claude" (default) or "gemini".
            model string — model name passed through to the provider (default: "claude-sonnet-4-6").
            credential_ref string — opaque credential identifier passed to AIClientFactory (default ""; ignored by the bundled env-var factory).
            client_factory_id string — selects a registered AIClientFactory by id (default "" → process default).
  Inputs:   Query *string, Candidates *[]string.
  Outputs:  Result int (0-based index), Reasoning string.
AIRerankOp: AI-powered reranking — returns a permutation of candidate indices, best first.
  Params:   max_retries string — parse/validation retries (default "3").
            api_retries string — transient-error retries with exponential backoff (default "3").
            api_retry_delay_ms string — initial backoff delay in milliseconds (default "500").
            api_factory_timeout_ms string — deadline for AIClientFactory credential lookup in milliseconds (default "30000"; "0" disables).
            provider string — AI provider: "claude" (default) or "gemini".
            model string — model name passed through to the provider (default: "claude-sonnet-4-6").
            credential_ref string — opaque credential identifier passed to AIClientFactory (default ""; ignored by the bundled env-var factory).
            client_factory_id string — selects a registered AIClientFactory by id (default "" → process default).
  Inputs:   Query *string, Candidates *[]string.
  Outputs:  Result []int (permutation as CSV), Reasoning string.
WithRepair: AI-driven recovery wrapper around a deterministic op.
  Mechanism: When the wrapped op returns *library.ErrRepairable, the wrapper
             forwards the error's Prompt verbatim (sandwiched by a configured
             PromptPrefix/PromptSuffix) to the LLM, parses the response into a
             fresh value of the named input field's type via the type's
             UnmarshalRepair method, writes it back via inner.SetInputField,
             and re-runs the inner op. Up to MaxAttempts repair cycles per Run;
             non-repairable errors are propagated unchanged.
  Inner contract:
             - Inner op returns *library.ErrRepairable when the failure is
               structural and fixable by an LLM mutation of its input.
             - The named input field must be a pointer type (e.g. *MyInput)
               whose element type implements library.RepairableInput
               (UnmarshalRepair(string) error).
             - Inner op MUST be idempotent or pure — repair retries re-execute Run.
  Registration:
             library.RegisterWithRepair[*InnerOp](name, factory, RepairConfig{...})
             called from init(). The wrapped vertex exposes the inner op's
             input/output field names verbatim — wire it in buildGraph
             identically to the unwrapped inner op.
  Params:    max_attempts string — repair cycle budget (default "3").
             provider     string — AI provider: "claude" (default) or "gemini".
             model        string — model passed to the provider (default "claude-sonnet-4-6").
             max_tokens   string — LLM response token budget (default "2048").
             credential_ref string — opaque credential identifier passed to AIClientFactory (default ""; ignored by the bundled env-var factory).
             client_factory_id string — selects a registered AIClientFactory by id (default "" → process default).
             api_retries        — see provider-level retry settings.
  Inputs/Outputs: identical to the wrapped inner op — wire by the inner op's field names.


## Time
CityTimeOp: returns the current time for a supported city.
  Input:  City *string — must be "New York" or "Tokyo"; any other value is a graph execution error.
  Output: Result string — current local time formatted as RFC3339.


## IO
FileReadOp: reads a file from disk. Input: Path *string. Output: Content string.
EnvOp: reads an environment variable. Input: Name *string. Output: Value string (empty if unset).
HTTPGetOp: performs an HTTP GET request. Input: URL *string. Outputs: Body string, StatusCode int.


## JSON
JSONExtractOp: extracts a value from a JSON string using a dot-separated path. Numeric path segments index into arrays (e.g. "meals.0.name"). Inputs: JSON *string, Path *string. Output: Value string (JSON-encoded leaf, or "" if not found).


## MCP
MCPCallOp: invoke a single MCP server tool as a DAG step.
Each Run opens a fresh session, completes the MCP handshake, calls the tool, and tears the
session down — unless pool_size > 0 opts into the warm-replenish pool (stdio only in v1).
  Params:   transport       — "stdio" (default) or "http". Selects how the MCP server is reached.
            stdio params:
              command         — server executable (e.g. "npx", "uvx", "/abs/path"). Required.
              args            — comma-separated CLI args. Optional.
              env             — comma-separated KEY=VALUE pairs. Optional.
            http params:
              url             — full endpoint URL (http or https). Required.
              headers         — comma-separated KEY=VALUE pairs injected into every request
                                (e.g. "Authorization=Bearer ${TOKEN}"). Optional.
            tool_name       — MCP tool to invoke. Required.
            init_timeout_ms — handshake timeout in ms (default "10000").
            call_timeout_ms — single tool call timeout in ms (default "30000").
            max_retries     — transient-error retries (default "3").
            pool_size       — warm-replenish pool target capacity per session-spec key
                              (default "0", no pool). Only supported for transport="stdio".
                              Pair with library.ShutdownMCPPool from main() so pre-started
                              subprocesses drain at exit.
            pool_prewarm    — when pool_size > 0, fill the pool during Setup (default "true").
  Inputs:   Input *In       — JSON-marshaled as the tool's "arguments" object. Implement
                              library.MCPArgsFormatter on *In to control marshaling.
  Outputs:  Result Out      — default dispatch handles string, float64, int, bool,
                              []string, []float64, []int, map[string]string, and any
                              struct decodable via json.Unmarshal (structured content
                              preferred when the server emits it). Implement
                              library.MCPResponseParser on *Out to fully control parsing.
Concrete variants embed library.MCPCallOp[In, Out] in a named struct and register via
operator.RegisterOp[ConcreteOp]() — never register the generic MCPCallOp directly.
MCPScriptOp: orchestrate a sequence of MCP tool calls against a single,
long-lived MCP session. Use this when one DAG step needs multiple tool calls
that share server-side state (browser session, file handles, etc.). The
user-supplied Script callback runs exactly once per Run, receives a
MCPSession, and is free to invoke CallTool any number of times in any order.
  Params:   transport       — "stdio" (default) or "http". Selects how the MCP server is reached.
            stdio params:
              command         — server executable (e.g. "npx", "uvx", "/abs/path"). Required.
              args            — comma-separated CLI args (e.g. "-y,@playwright/mcp@latest"). Optional.
              env             — comma-separated KEY=VALUE pairs. Optional.
            http params:
              url             — full endpoint URL (http or https). Required.
              headers         — comma-separated KEY=VALUE pairs injected into every request
                                (e.g. "Authorization=Bearer ${TOKEN}"). Optional.
            init_timeout_ms — handshake timeout in ms (default "10000").
            call_timeout_ms — per-tool-call timeout in ms (default "30000").
            max_retries     — retries for session-start failures only; the Script runs at most
                              once per Run (default "3").
            pool_size       — warm-replenish pool target capacity per session-spec key
                              (default "0", no pool). Vertices with the same spec share warm
                              slots; each Run gets a fresh session — sessions are never reused
                              for a second Run. Only supported for transport="stdio" in v1.
                              Pair with library.ShutdownMCPPool from main() so pre-started
                              subprocesses drain at exit.
            pool_prewarm    — when pool_size > 0, fill the pool during Setup (default "true");
                              set "false" to fill lazily on first Run.
  Inputs:   Input *In       — typed input handed to Script.
  Outputs:  Result Out      — populated by Script.
Concrete variants embed library.MCPScriptOp[In, Out] in a named struct and
register via operator.RegisterOpFactory(name, factory), with the Script field
assigned in the factory closure.

